<?php

namespace App\http\controllers;

class classConroller extends Controller 
{
   function newsCategori() 
      {
     return array = [newnews,news_Categori,updated_news,updated_categori,Updating_public_data];
     $information_categori = [new_Category_News,new_updates,new_modifications,new_ads];
      }
     echo "<h1><a href="$information_categori">Категории</a></h1>" ; 
}